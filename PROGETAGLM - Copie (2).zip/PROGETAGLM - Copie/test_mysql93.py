import mysql.connector
from mysql.connector import Error

def test_mysql93_connection():
    try:
        print("Tentative de connexion au service MySQL93...")
        
        # Essayer avec différentes configurations de connexion
        configs = [
            {"host": "localhost", "user": "root", "password": "", "database": "donnee_app"},
            {"host": "localhost", "user": "MySQL93", "password": "", "database": "donnee_app"},
            {"host": "localhost", "user": "MySQL93", "password": "root", "database": "donnee_app"},
            {"host": "localhost", "user": "root", "password": "root", "database": "donnee_app"},
            {"host": "localhost", "user": "admin", "password": "admin", "database": "donnee_app"}
        ]
        
        for config in configs:
            try:
                print(f"\nEssai avec {config['user']}@{config['host']}...")
                connection = mysql.connector.connect(**config)
                
                if connection.is_connected():
                    print(f"✅ Connexion réussie avec {config['user']}@{config['host']}")
                    
                    cursor = connection.cursor()
                    
                    # Afficher les bases de données
                    cursor.execute("SHOW DATABASES")
                    print("\nBases de données disponibles:")
                    for (db,) in cursor:
                        print(f"- {db}")
                    
                    # Vérifier si la base de données existe
                    cursor.execute("SHOW DATABASES LIKE 'donnee_app'")
                    if cursor.fetchone():
                        print("\n✅ La base de données 'donnee_app' existe.")
                        
                        # Utiliser la base de données
                        cursor.execute("USE donnee_app")
                        
                        # Vérifier si la table Notifications existe
                        cursor.execute("SHOW TABLES LIKE 'Notifications'")
                        if cursor.fetchone():
                            print("✅ La table 'Notifications' existe déjà.")
                        else:
                            print("La table 'Notifications' n'existe pas encore.")
                    
                    cursor.close()
                    connection.close()
                    return True
                    
            except Error as e:
                print(f"❌ Échec de la connexion: {e}")
                
    except Exception as e:
        print(f"Erreur inattendue: {e}")
    
    return False

if __name__ == "__main__":
    print("=== Test de connexion à MySQL93 ===")
    if not test_mysql93_connection():
        print("\n❌ Impossible de se connecter à la base de données avec les paramètres par défaut.")
        print("Veuillez vérifier que :")
        print("1. Le service MySQL est en cours d'exécution")
        print("2. Les identifiants de connexion sont corrects")
        print("3. L'utilisateur a les droits nécessaires")
    else:
        print("\n✅ Test de connexion terminé avec succès !")

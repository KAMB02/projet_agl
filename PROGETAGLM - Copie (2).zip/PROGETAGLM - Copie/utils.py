def deconnecter(page: 'ft.Page'):
    """Déconnecte l'utilisateur et redirige vers la page de connexion"""
    # Supprimer les données de session
    page.session.clear()
    # Rediriger vers la page de connexion
    page.go("/page5")

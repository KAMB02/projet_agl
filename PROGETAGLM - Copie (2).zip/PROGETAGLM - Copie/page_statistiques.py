import flet as ft
import mysql.connector
from mysql.connector import Error
# Définition des couleurs
BG = "#041955"   # Bleu foncé
FWG = "#FFFFFF"  # Blanc
FG = "#3450a1"   # Bleu clair
PINK = "#eb06ff" # Rose
# Fonction pour récupérer les données de la base de données
def fetch_statistics():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='donnee_app',
            user='root',
            password='labo'
        )

        if connection.is_connected():
            cursor = connection.cursor()
            cursor.execute("""
                SELECT 
                    e.Nom, e.Prenoms, 
                    COUNT(pe.Id_pres) AS nb_presences, 
                    SUM(TIMESTAMPDIFF(MINUTE, pe.Heure_debut, pe.Heure_fin)) AS total_minutes
                FROM 
                    Enseignant e
                LEFT JOIN 
                    Presence_ens pe ON e.Id_ens = pe.Id_ens
                GROUP BY 
                    e.Id_ens 
            """)
            stats = cursor.fetchall()
            return stats

    except Error as e:
        print(f"Erreur lors de la connexion à MySQL: {e}")
        return None

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("Connexion MySQL fermée")


#statistique en courbe
class State:
    toggle = True
s = State()
import flet as ft
def page_statistiques(page: ft.Page):
    title = ft.Text(" STATISTIQUES ", size=30, color="WHITE",  weight=ft.FontWeight.BOLD)
    content = ft.Column(
        controls=[
            title,
            ft.Text(" Choisissez une option svp", color="WHITE"),
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    )

    # Fonction pour gérer les clics sur la barre de navigation
    def navigation_changed(e):
        if e.control.selected_index == 0:
            page.go("/page_accueil")  # Accueil
        elif e.control.selected_index == 1:
            page.go("/page_emploi_temps")  # Emploi du temps
        elif e.control.selected_index == 2:
            page.go("/page_statistiques")  # Statistiques
        elif e.control.selected_index == 3: 
            page.go("/page_profil")
    # Barre de navigation
    navigation_bar = ft.CupertinoNavigationBar(
        bgcolor=ft.colors.WHITE,
        inactive_color=ft.colors.BLACK,
        active_color=ft.colors.BLUE,
        on_change=navigation_changed,
        destinations=[
            ft.NavigationBarDestination(
                icon=ft.Icon(ft.icons.HOME_ROUNDED, color="black"),
                selected_icon=ft.Icon(ft.icons.HOME_ROUNDED, color="BLUE"),
                label="Accueil"
            ),
            ft.NavigationBarDestination(
                icon=ft.Icon(ft.icons.CALENDAR_TODAY, color="black"),
                selected_icon=ft.Icon(ft.icons.CALENDAR_TODAY, color="BLUE"),
                label="Emploi du temps"
            ),
            ft.NavigationBarDestination(
                icon=ft.Icon(ft.icons.SHOW_CHART, color="black"),
                selected_icon=ft.Icon(ft.icons.SHOW_CHART, color="BLUE"),
                label="Statistiques"
            ),
            ft.NavigationBarDestination(
                icon=ft.Icon(ft.icons.PERSON_2, color="black"),
                selected_icon=ft.Icon(ft.icons.PERSON_2, color="BLUE"),
                label="Profil"
            ),
        ],
    )
     # Définir la couleur de fond de la page
    page.bgcolor = BG 
    
    stat1 = ft.ElevatedButton(text="STATISTIQUE EN COURBE", on_click=lambda e: page.go('/page_stat1'))
    stat2 = ft.ElevatedButton(text="STATISTIQUE EN DIAGRAMME", on_click=lambda e: page.go('/page_stat2'))
   
    def handle_expansion_tile_change(e):
        page.open(
            ft.SnackBar(
                ft.Text(f"ExpansionTile was {'expanded' if e.data=='true' else 'collapsed'}"),
                duration=1000,
            )
        )
        if e.control.trailing:
            e.control.trailing.name = (
                ft.Icons.ARROW_DROP_DOWN
                if e.control.trailing.name == ft.Icons.ARROW_DROP_DOWN_CIRCLE
                else ft.Icons.ARROW_DROP_DOWN_CIRCLE
            )
            page.update()

    page.spacing = 0
    page.padding = 0

    expansion_tiles = [
        ft.ExpansionTile(
            title=ft.Text("RESUME DES STATISTIQUES"),
            subtitle=ft.Text("Cliquez sur les boutons pour voir les statistiques"),
            affinity=ft.TileAffinity.PLATFORM,
            maintain_state=True,
            collapsed_text_color=ft.Colors.RED,
            text_color=ft.Colors.RED,
            controls=[ft.ListTile(title=ft.Text("Ceci est un résumé des statistiques"))],
        ),
        ft.ExpansionTile(
            title=ft.Text("Présence"),
            subtitle=ft.Text("Cliquez sur les boutons pour voir les statistiques"),
            trailing=ft.Icon(ft.Icons.ARROW_DROP_DOWN),
            collapsed_text_color=ft.Colors.GREEN,
            text_color=ft.Colors.GREEN,
            on_change=handle_expansion_tile_change,
            controls=[ft.ListTile(title=ft.Text("Plus ou moins ponctuel"))],
        ),
        ft.ExpansionTile(
            title=ft.Text("Absences"),
            subtitle=ft.Text("Cliquez sur les boutons pour voir les statistiques"),
            affinity=ft.TileAffinity.LEADING,
            initially_expanded=True,
            collapsed_text_color=ft.Colors.BLUE,
            text_color=ft.Colors.BLUE,
            controls=[
                ft.ListTile(title=ft.Text("Absent le 03/04/2025 à 08:00")),
                ft.ListTile(title=ft.Text("Absent le 03/04/2025 à 09:00")),
                ft.ListTile(title=ft.Text("Absent le 03/04/2025 à 10:00")),
                ft.ListTile(title=ft.Text("Absent le 03/04/2025 à 10:00")),
                ft.ListTile(title=ft.Text("Absent le 03/04/2025 à 10:00")),
                ft.ListTile(title=ft.Text("Absent le 03/04/2025 à 10:00")),
                ft.ListTile(title=ft.Text("Absent le 03/04/2025 à 10:00")),
            ],
        ),
    ]

    # Utilisation d'un ListView pour permettre le défilement
    list_view = ft.ListView(controls=expansion_tiles, expand=True)
    def update_statistics():
        stats = fetch_statistics()
        if stats:
            content.controls.clear()
            content.controls.append(title)
            for stat in stats:
                content.controls.append(ft.Text(f"{stat[0]} {stat[1]} - Présences: {stat[2]}, Temps total: {stat[3]} minutes", color="WHITE"))
        else:
            content.controls.append(ft.Text("Erreur lors de la récupération des données", color="RED"))
        page.update()

    update_statistics()

   

    # Retourner une liste contenant les contrôles de la page des statistiques
    return [ft.IconButton(icon=ft.icons.ARROW_BACK, icon_color="WHITE", on_click=lambda _: page.go('/page_accueil')), content,stat1,stat2,navigation_bar, list_view]
import flet as ft
import mysql.connector
from mysql.connector import Error
import bcrypt
from fonction import *
import time



# Message pour afficher les erreurs ou les succès
message = ft.Text("", size=20, weight='bold')

# Page de connexion
def page_1(page: ft.Page):
    page.title = "PAGE DE CONNEXION"
    page.vertical_alignment = 'center'

    # Navigation vers les autres pages
    def s_inscrire(e):
        page.go("/page2")

    def oublier(e):
        page.go('/page3')

    # Récupérer les utilisateurs depuis la table `utilisateurs`


    list_users = get_users()
    list_numero = [str(user[2]) for user in list_users]
    list_mot_passe = [user[5] for user in list_users]  # Hashed passwords
    list_profession = [str(user[4]) for user in list_users]
    list_nomComplet = [f"{user[0]} {user[1]}" for user in list_users]
    list_email = [str(user[3]) for user in list_users]
    list_user_id = [user[6] if len(user) > 6 else None for user in list_users]  # ID spécialisé
    # Vérification des identifiants
    def identite(numero, mot_passe):
        if numero in list_numero:
            index = list_numero.index(numero)
            # Vérifier le mot de passe haché
            stored_password = list_mot_passe[index].encode('utf-8')
            if bcrypt.checkpw(mot_passe.encode('utf-8'), stored_password):
                return index
        return None

    # Gestion de la connexion
    # Gestion de la connexion
    def connexion(e):
        num = numero.value.strip()
        mdp = mot_de_passe.value.strip()
        adresse = "N/A"
        ip = "N/A"
        if not num or not mdp:
            message.value = "Veuillez remplir tous les champs."
            message.color = "red"
        else:
            index = identite(num, mdp)
            if index is not None:
                # Récupérer l'adresse et l'IP depuis la table spécialisée
                user_profession = list_profession[index]
                user_id = list_user_id[index] if list_user_id[index] else num
                try:
                    connection = create_connection()
                    if connection:
                        cursor = connection.cursor()
                        
                        if user_profession == 'Etudiant':
                            # Vérifier si l'étudiant existe et récupérer ses données
                            cursor.execute("SELECT adresse, IP FROM etudiant WHERE Numero = %s", (user_id,))
                            print(f"Requête pour l'étudiant {user_id}: {cursor.statement}")
                            result = cursor.fetchone()
                            if result:
                                print(f"Résultat trouvé: {result}")
                                adresse = result[0] if result[0] else "N/A"
                                ip = result[1] if result[1] else "N/A"
                            else:
                                print(f"Étudiant non trouvé pour le numéro {user_id}")
                                adresse = "N/A"
                                ip = "N/A"
                        elif user_profession == 'Enseignant':
                            # Vérifier d'abord si l'enseignant existe
                            cursor.execute("SELECT Id_ens, adresse FROM enseignant WHERE Id_ens = %s", (user_id,))
                            result = cursor.fetchone()
                            if result:
                                # Si l'enseignant existe, utiliser son ID et récupérer l'adresse
                                user_id = result[0]
                                adresse = result[1] if result[1] else "N/A"
                            else:
                                # Si l'enseignant n'existe pas, vérifier avec le numéro
                                cursor.execute("SELECT Id_ens, adresse FROM enseignant WHERE Numero = %s", (num,))
                                result = cursor.fetchone()
                                if result:
                                    user_id = result[0]
                                    adresse = result[1] if result[1] else "N/A"
                                else:
                                    print(f"Aucun enseignant trouvé avec l'ID {user_id} ou le numéro {num}")
                                    adresse = "N/A"
                        elif user_profession == 'Administration':
                            cursor.execute("SELECT adresse, Id_adm FROM administration WHERE Id_adm = %s", (user_id,))
                            result = cursor.fetchone()
                            if result:
                                adresse = result[0] if result[0] else "N/A"
                                adresse = "N/A"
                        
                        cursor.close()
                        connection.close()
                        
                except Error as e:
                    print(f"Erreur lors de la récupération des données: {e}")
                    adresse = "N/A"
                    ip = "N/A"
                
                # Stocker toutes les informations de l'utilisateur dans la session en une seule fois
                user_data = {
                    "nom": list_users[index][0],
                    "prenom": list_users[index][1],
                    "email": list_users[index][3],
                    "profession": list_users[index][4],
                    "numero": list_users[index][2],
                    "adresse": adresse,
                    "IP": ip,
                    "id": user_id
                }
                page.session.set("user", user_data)
                print(f"Données stockées dans la session: {user_data}")
                message.value = f"Connexion réussie en tant que {list_profession[index]}"
                message.color = "green"
                page.update()
                time.sleep(1)
                if list_profession[index] == 'Etudiant':
                    page.go('/page_etu_acc')
                elif list_profession[index] == 'Enseignant':
                    page.go('/page_accueil')
                elif list_profession[index] == 'Administration':
                    page.go('/page_admins')
            else:
                message.value = "Numéro ou mot de passe incorrect."
                message.color = "red"
        page.update()

    # Champs de saisie
    numero = ft.TextField(label="NUMERO", border_radius=20, border_color='white', bgcolor="white", width=400, color='black')
    mot_de_passe = ft.TextField(label="MOT DE PASSE", password=True, border_radius=20, border_color='white', can_reveal_password=True, bgcolor='white', width=400, color='black')

    # Boutons
    btn_connexion = ft.ElevatedButton("CONNEXION", animate_size=20, bgcolor='#90EE90', color='black', on_click=connexion)
    btn_inscrire = ft.ElevatedButton("S'INSCRIRE", on_click=s_inscrire, animate_size=50, bgcolor='lightblue', color='black')
    btn_oublier = ft.TextButton("MOT DE PASSE OUBLIÉ", on_click=oublier, style=ft.ButtonStyle(color='black'))
    btn_retour = ft.ElevatedButton("RETOUR", on_click=lambda _: page.go("/page5"), animate_size=50, bgcolor='white', color='black')

    # Agencement de la page
    champ = [
        ft.Column([
            ft.Text("Se connecter pour continuer", size=25, weight="bold", color='white'),
            numero,
            mot_de_passe,
            ft.Row([btn_connexion, btn_inscrire], alignment=ft.MainAxisAlignment.CENTER, spacing=30),
            ft.Row([btn_oublier], alignment=ft.MainAxisAlignment.CENTER)
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        btn_retour,
        message
    ]

    return [
        ft.Column(
            champ,
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            expand=True
        )
    ]
import mysql.connector

# Connexion à la base de données
try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",  # Remplacez par votre nom d'utilisateur MySQL
        password="",  # Remplacez par votre mot de passe MySQL
        database="donnee_app"
    )
    
    cursor = conn.cursor()
    
    # Lecture du fichier SQL
    with open('ajouter_table_notifications.sql', 'r', encoding='utf-8') as f:
        sql_script = f.read()
    
    # Exécution des commandes SQL
    for result in cursor.execute(sql_script, multi=True):
        if result.with_rows:
            print("Résultat:", result.fetchall())
    
    conn.commit()
    print("Table 'Notifications' créée avec succès !")
    
except mysql.connector.Error as err:
    print(f"Erreur MySQL: {err}")
    
finally:
    if 'conn' in locals() and conn.is_connected():
        cursor.close()
        conn.close()
        print("Connexion MySQL fermée")

from page_profil import page_profil

from flet import*
from  page_admin import*

def main(page: Page):

    BG = '#041955'
    fond = '#3450a1'
    bulle='#2BC2A9'
    page.bgcolor=BG
    # Configuration de la gestion des routes
    def on_route_change(e):
        page.views.clear()
        if page.route == "/page_admins":
            page.views.append(View(route="/page_admins",controls=page_b(page),bgcolor=fond))
        elif page.route == "/page_admin":
            page.views.append(View(route="/page_admin",controls=page_admin(page,"Yao Ama"),bgcolor=fond))      
        page.update()

    # Configuration initiale
    page.on_route_change = on_route_change
    page.go("/page_admin")  # Page de démarrage

app(target=main)
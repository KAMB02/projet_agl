import flet as ft
import mysql.connector
from mysql.connector import Error
# Définition des couleurs
BG = "#041955"   # Bleu foncé
FWG = "#FFFFFF"  # Blanc
FG = "#3450a1"   # Bleu clair
PINK = "#eb06ff" # Rose
# Fonction pour récupérer les données de la base de données
def fetch_statistics():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='donnee_app',
            user='root',
            password='labo'
        )

        if connection.is_connected():
            cursor = connection.cursor()
            cursor.execute("""
                SELECT 
                    e.Nom, e.Prenoms, 
                    COUNT(pe.Id_pres) AS nb_presences, 
                    SUM(TIMESTAMPDIFF(MINUTE, pe.Heure_debut, pe.Heure_fin)) AS total_minutes
                FROM 
                    Enseignant e
                LEFT JOIN 
                    Presence_ens pe ON e.Id_ens = pe.Id_ens
                GROUP BY 
                    e.Id_ens 
            """)
            stats = cursor.fetchall()
            return stats

    except Error as e:
        print(f"Erreur lors de la connexion à MySQL: {e}")
        return None

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("Connexion MySQL fermée")

#statistique en courbe
class State:
    toggle = True
s = State()
def page_stat2(page: ft.Page):
    title = ft.Text(" STATISTIQUES ", size=30, color="WHITE",  weight=ft.FontWeight.BOLD)
 # 2. Statistiques en diagramme
    stats = fetch_statistics()
    if stats:
        total_presences = sum(stat[2] for stat in stats)
        total_absences = 100 - total_presences  # Exemple simplifié
    else:
        total_presences = 0
        total_absences = 0

    chart = ft.PieChart(
        sections=[
            ft.PieChartSection(
                total_presences,
                title=f"{total_presences}% de présence",
                title_style=ft.TextStyle(size=16, color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD),
                color=ft.Colors.BLUE,
                radius=50,
            ),
            ft.PieChartSection(
                total_absences,
                title=f"{total_absences}% d'absence",
                title_style=ft.TextStyle(size=16, color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD),
                color=ft.Colors.PURPLE,
                radius=50,
            ),
        ],
        sections_space=0,
        center_space_radius=40,
        expand=True,
    )
 # Retourner une liste contenant les contrôles de la page des statistiques
    return [ft.IconButton(icon=ft.icons.ARROW_BACK, icon_color="WHITE", on_click=lambda _: page.go('/page_statistiques')), chart]
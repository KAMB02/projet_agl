from flet import *
from utils import deconnecter

def page_etu_profil(page: Page, name=None):
    page.adaptive = True
    page.title = "Profil Étudiant"
    
    # Palette de couleurs
    primary_color = "#667eea"  # Bleu-violet moderne
    secondary_color = "#041955"  # Rose doux
    other_color = "#2BC2A9"  # Vert menthe
    background_color = "#3450a1"  # Gris très clair
    card_color = "#041955"
    card_color2 = "#1C3989"  # Gris clair pour les cartes
    text_primary = "#f9f9fa"  # Gris foncé
    text_secondary = "#f8fafd"  # Gris moyen
    text_light = "#ffffff"  # Blanc
    shadow_color = "#516ec5"  # Gris clair pour ombres

    # Récupérer les informations de l'utilisateur depuis la session
    user = page.session.get("user") or {
        "nom": "Inconnu",
        "prenom": "Inconnu",
        "email": "inconnu@example.com",
        "numero": "0000000000",
        "adresse": "N/A",
        "profession": "Étudiant"
    }

    # Fonction pour créer un gradient
    def create_gradient_container(content, Colors_list):
        return Container(
            content=content,
            gradient=LinearGradient(
                begin=alignment.top_left,
                end=alignment.bottom_right,
                colors=Colors_list
            ),
            border_radius=15,
            shadow=BoxShadow(
                spread_radius=1,
                blur_radius=10,
                color=shadow_color,
                offset=Offset(0, 4)
            )
        )

    # Fonction pour gérer les clics sur la barre de navigation
    def navigation_changed(e):
        if e.control.selected_index == 0:
            page.go("/page_etu_acc")  # Accueil
        elif e.control.selected_index == 1:
            page.go("/page_marquer_presence")  # Pointage
        elif e.control.selected_index == 2:
            page.go("/page_etu_stats")  # Statistiques
        elif e.control.selected_index == 3: 
            page.go("/page_etu_profil")  # Profil
    
    # Barre de navigation
    navigation_bar = CupertinoNavigationBar(
        bgcolor=Colors.WHITE,
        inactive_color=Colors.BLACK,
        active_color=Colors.BLUE,
        on_change=navigation_changed,
        destinations=[
            NavigationBarDestination(
                icon=Icons.HOME_ROUNDED,
                selected_icon=Icons.HOME_ROUNDED,
                label="Accueil"
            ),
            NavigationBarDestination(
                icon=Icons.FINGERPRINT,
                selected_icon=Icons.FINGERPRINT,
                label="Pointage"
            ),
            NavigationBarDestination(
                icon=Icons.SHOW_CHART,
                selected_icon=Icons.SHOW_CHART,
                label="Statistiques"
            ),
            NavigationBarDestination(
                icon=Icons.PERSON_2,
                selected_icon=Icons.PERSON_2,
                label="Profil"
            ),
        ],
    )

    # Les informations de l'étudiant depuis la session
    infos_etudiant = [
        user["nom"],
        user["prenom"],
        user["numero"],
        user["email"],
        user.get("adresse", "N/A")
    ]
    
    det_infos_etudiant = ["Nom", "Prénoms", "Numéro de téléphone", "Email", "Adresse"]
    icones_infos = [Icons.BADGE, Icons.PERSON, Icons.PHONE, Icons.EMAIL, Icons.HOME]

    # En-tête avec avatar
    header = create_gradient_container(
        Column(
            controls=[
                Container(height=20),
                CircleAvatar(
                    radius=50,
                    bgcolor=card_color,
                    content=Icon(Icons.PERSON, size=60, color=primary_color)
                ),
                Container(height=15),
                Text(
                    f"{user['prenom']} {user['nom']}",
                    size=24,
                    weight=FontWeight.BOLD,
                    color=text_light,
                    text_align=TextAlign.CENTER
                ),
                Text(
                    user.get("profession", "Étudiant"),
                    size=16,
                    color=text_light,
                    text_align=TextAlign.CENTER,
                    opacity=0.9
                ),
                Container(height=20),
            ],
            horizontal_alignment=CrossAxisAlignment.CENTER,
        ),
        [primary_color, secondary_color]
    )

    # Conteneur des informations
    info_cards = Column(spacing=15)
    
    for info, label, icon in zip(infos_etudiant, det_infos_etudiant, icones_infos):
        info_content = Row(
            controls=[
                Container(
                    width=50,
                    height=50,
                    bgcolor=f"{other_color}15",  # Fond vert menthe avec transparence
                    border_radius=25,
                    content=Icon(icon, color=other_color, size=24),
                    alignment=alignment.center
                ),
                Container(width=15),
                Column(
                    controls=[
                        Text(label, size=12, color=other_color, weight=FontWeight.W_500),
                        Text(str(info), size=16, color=text_primary, weight=FontWeight.BOLD)
                    ],
                    spacing=2,
                    expand=True
                )
            ],
            alignment=MainAxisAlignment.START
        )
        
        info_card = create_gradient_container(
            content=Container(
                content=info_content,
                padding=20
            ),
            Colors_list=[card_color2, card_color]
        )
        
        info_cards.controls.append(info_card)

    # Boutons d'action
    action_buttons = Column(
        controls=[
            ElevatedButton(
                "Se déconnecter",
                icon=Icons.LOGOUT,
                on_click=lambda e: deconnecter(page),
                style=ButtonStyle(
                    bgcolor=other_color,
                    color=text_light,
                    shape=RoundedRectangleBorder(radius=25),
                    padding=padding.symmetric(horizontal=25, vertical=12)
                ),
                expand=True
            )
        ],
        spacing=10
    )

    # Bouton retour moderne
    retour = Container(
        content=IconButton(
            icon=Icons.ARROW_BACK_IOS,
            icon_color=text_primary,
            on_click=lambda _: page.go('/page_etu_acc'),
            style=ButtonStyle(
                shape=CircleBorder(),
                bgcolor=card_color,
                shadow_color=shadow_color
            )
        ),
        padding=padding.only(left=10, top=10)
    )

    # Conteneur principal avec scroll
    main_content = Container(
        bgcolor=background_color,
        expand=True,
        content=Column(
            controls=[
                retour,
                Container(height=10),
                Container(
                    padding=padding.symmetric(horizontal=20),
                    content=header
                ),
                Container(height=20),
                Container(
                    padding=padding.symmetric(horizontal=20),
                    content=Column(
                        controls=[
                            Text("Informations personnelles", 
                                size=20, 
                                weight=FontWeight.BOLD, 
                                color=other_color),
                            Container(height=10),
                            info_cards,
                            Container(height=20),
                            action_buttons,
                            Container(height=100)
                        ]
                    )
                )
            ],
            scroll=ScrollMode.AUTO
        )
    )

    # Structure finale
    page_structure = Stack(
        controls=[
            main_content,
            Container(
                content=navigation_bar,
                alignment=alignment.bottom_center,
                bottom=0,
                left=0,
                right=0
            )
        ],
        expand=True
    )

    # Déconnexion - VERSION CORRIGÉE
    def deconnecter(e):
        # Créer et afficher la boîte de dialogue de confirmation
        dlg_modal = AlertDialog(
            modal=True,
            title=Text("Déconnexion", color=text_primary),
            content=Text("Voulez-vous vraiment vous déconnecter ?", color=text_secondary),
            actions=[
                TextButton(
                    "Oui",
                    on_click=lambda _: page.go("/page5"),
                    style=ButtonStyle(color=other_color)
                ),
                TextButton(
                    "Non",
                    on_click=lambda _: dlg_modal.close(),
                    style=ButtonStyle(color=text_secondary)
                )
            ],
            actions_alignment=MainAxisAlignment.END,
            on_dismiss=lambda e: print("Fenêtre de déconnexion fermée"),
            bgcolor=card_color,
        )
        page.dialog = dlg_modal
        dlg_modal.open = True
        page.update()

    return [page_structure]
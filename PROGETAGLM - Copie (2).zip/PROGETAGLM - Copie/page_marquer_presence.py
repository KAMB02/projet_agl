import flet as ft
from datetime import datetime, time
import mysql.connector
from mysql.connector import Error

def page_marquer_presence(page: ft.Page, etudiant_connecte):
    def checkbox_changed(e):
        if not e.control.value:
            return

        try:
            # Connexion à la base de données
            connection = mysql.connector.connect(
                host='localhost',
                database='donnee_app',
                user='root',
                password='Kamssone25',
                port='3308'
            )

            if connection.is_connected():
                cursor = connection.cursor()

                # Récupérer le numéro de téléphone de l'étudiant
                numero_etudiant = etudiant_connecte.get('numero')
                if not numero_etudiant:
                    t.value = "Erreur : Numéro de téléphone de l'étudiant non trouvé"
                    t.color = 'red'
                    t.weight = ft.FontWeight.BOLD
                    checkbox.disabled = True
                    page.update()
                    return

                # Récupérer l'IP et le groupe de l'étudiant
                cursor.execute(
                    "SELECT IP, Id_gpe_td FROM Etudiant WHERE Numero = %s",
                    (numero_etudiant,)
                )
                etudiant = cursor.fetchone()
                if not etudiant:
                    t.value = f"Erreur : Numéro {numero_etudiant} n'existe pas dans la table étudiant"
                    t.color = 'red'
                    t.weight = ft.FontWeight.BOLD
                    checkbox.disabled = True
                    page.update()
                    return

                ip_etudiant, id_gpe_td = etudiant
                print(f"Étudiant trouvé : IP={ip_etudiant}, Id_gpe_td={id_gpe_td}")

                # Vérifier si un professeur est présent pour un cours aujourd'hui
                date_aujourdhui = datetime.now().date()
                current_time = datetime.now().time()
                cursor.execute(
                    """
                    SELECT p.Id_pres, e.Id_cours
                    FROM Presence_ens p
                    JOIN Emploi_du_temps e ON p.Id_Salle = e.Id_salle AND DATE(p.Date_presence) = e.Date_cours
                    JOIN Cours c ON e.Id_cours = c.Id_cours
                    WHERE DATE(p.Date_presence) = %s
                    """,
                    (date_aujourdhui,)
                )
                presence_prof = cursor.fetchone()

                if not presence_prof:
                    t.value = "Erreur : Aucun professeur n'a marqué sa présence pour un cours aujourd'hui"
                    t.color = 'red'
                    t.weight = ft.FontWeight.BOLD
                    checkbox.disabled = True
                    page.update()
                    return
                Id_pres = presence_prof[0]
                id_cours = presence_prof[1]  # Récupérer l'ID du cours

                # Vérifier si l'étudiant a déjà marqué sa présence pour ce cours aujourd'hui
                cursor.execute(
                    """
                    SELECT Id_pres
                    FROM Presence_etu pe
                    WHERE pe.IP = %s AND DATE(pe.Date_presence) = %s
                    AND EXISTS (
                        SELECT 1 FROM Emploi_du_temps e
                        WHERE e.Id_cours = %s AND DATE(e.Date_cours) = DATE(pe.Date_presence)
                    )
                    """,
                    (ip_etudiant, date_aujourdhui, id_cours)
                )
                result = cursor.fetchone()

                if result:
                    t.value = "Vous avez déjà marqué votre présence pour ce cours aujourd'hui !"
                    t.color = 'orange'
                    t.weight = ft.FontWeight.BOLD
                    checkbox.disabled = True
                else:
                    try:
                        # Insérer la nouvelle présence
                        date_presence = datetime.now()
                        heure_debut = current_time.strftime('%H:%M:%S')
                       

                        cursor.execute(
                            "INSERT INTO Presence_etu (Id_pres,IP,Date_presence,Heure_debut,Heure_fin) VALUES (%s, %s, %s, %s,%s)",
                            (Id_pres,ip_etudiant,date_aujourdhui, heure_debut,heure_debut)
                        )
                        connection.commit()
                        t.value = "Présence marquée avec succès !"
                        t.color = 'green'
                        t.weight = ft.FontWeight.BOLD
                        checkbox.disabled = True
                    except Error as e:
                        print(f"Erreur lors de l'insertion : {e}")
                        t.value = f"Erreur : {str(e)}"
                        t.color = 'red'
                        t.weight = ft.FontWeight.BOLD

            else:
                t.value = "Erreur : Connexion à la base de données échouée"
                t.color = 'red'
                t.weight = ft.FontWeight.BOLD
                checkbox.disabled = True

        except Error as e:
            print(f"Erreur lors de la connexion à MySQL : {e}")
            t.value = f"Erreur : {str(e)}"
            t.color = 'red'
            t.weight = ft.FontWeight.BOLD
            checkbox.disabled = True

        finally:
            if connection and connection.is_connected():
                cursor.close()
                connection.close()
                print("Connexion MySQL fermée")

        page.update()

    # Initialisation de l'objet texte pour les erreurs/succès
    t = ft.Text()

    # Checkbox pour marquer la présence
    checkbox = ft.Checkbox(label="Marquer ma présence", on_change=checkbox_changed)

    # Vérifier au chargement si l'étudiant peut marquer sa présence
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='donnee_app',
            user='root',
            password='Kamssone25',
            port='3308'
        )
        if connection.is_connected():
            cursor = connection.cursor()
            numero_etudiant = etudiant_connecte.get('numero')
            date_aujourdhui = datetime.now().date()
            current_time = datetime.now().time()

            # Récupérer l'IP et le groupe de l'étudiant
            cursor.execute(
                "SELECT IP, Id_gpe_td FROM Etudiant WHERE Numero = %s",
                (numero_etudiant,)
            )
            etudiant = cursor.fetchone()
            if not etudiant:
                t.value = f"Erreur : Numéro {numero_etudiant} n'existe pas dans la table étudiant"
                t.color = 'red'
                t.weight = ft.FontWeight.BOLD
                checkbox.disabled = True
                page.update()
            else:
                ip_etudiant, id_gpe_td = etudiant
                # Vérifier si un professeur est présent
                cursor.execute(
                    """
                    SELECT p.Id_pres, e.Id_cours
                    FROM Presence_ens p
                    JOIN Emploi_du_temps e ON p.Id_Salle = e.Id_salle AND DATE(p.Date_presence) = e.Date_cours
                    JOIN Cours c ON e.Id_cours = c.Id_cours
                    WHERE DATE(p.Date_presence) = %s
                    AND p.Heure_debut <= %s AND p.Heure_fin >= %s
                    """,
                    (date_aujourdhui, current_time.strftime('%H:%M:%S'), current_time.strftime('%H:%M:%S'))
                )
                presence_prof = cursor.fetchone()

                if not presence_prof:
                    t.value = "Présence non disponible : Aucun professeur n'a marqué sa présence pour un cours aujourd'hui"
                    t.color = 'red'
                    t.weight = ft.FontWeight.BOLD
                    checkbox.disabled = True
                else:
                    # Vérifier si l'étudiant a déjà marqué sa présence pour le cours
                    cursor.execute(
                        """
                        SELECT Id_pres
                        FROM Presence_etu pe
                        WHERE pe.IP = %s AND DATE(pe.Date_presence) = %s
                        AND EXISTS (
                            SELECT 1 FROM Emploi_du_temps e
                            WHERE e.Id_cours = %s AND DATE(e.Date_cours) = DATE(pe.Date_presence)
                        )
                        """,
                        (ip_etudiant, date_aujourdhui, presence_prof[1] if presence_prof else 0)
                    )
                    if cursor.fetchone():
                        t.value = "Vous avez déjà marqué votre présence pour ce cours aujourd'hui !"
                        t.color = 'orange'
                        t.weight = ft.FontWeight.BOLD
                        checkbox.disabled = True

        else:
            t.value = "Erreur : Connexion à la base de données échouée"
            t.color = 'red'
            t.weight = ft.FontWeight.BOLD
            checkbox.disabled = True

    except Error as e:
        print(f"Erreur lors de la vérification initiale : {e}")
        t.value = f"Erreur : {str(e)}"
        t.color = 'red'
        t.weight = ft.FontWeight.BOLD
        checkbox.disabled = True

    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()
            print("Connexion MySQL fermée initiale")

    page.update()

    # Retourner une liste de widgets
    return [
        ft.IconButton(icon=ft.Icons.ARROW_BACK, icon_color="white", on_click=lambda _: page.go('/page_etu_acc')),
        ft.Text(value="MARQUER MA PRÉSENCE", color="white", weight=ft.FontWeight.BOLD, size=18),
        ft.Container(content=checkbox, alignment=ft.alignment.center),
        t,
    ]
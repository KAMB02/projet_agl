import mysql.connector
from mysql.connector import Error

def check_table_structure():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='donnee_app',
            user='root',
            password='Kamssone25',
            port=3308
        )
        
        if connection.is_connected():
            cursor = connection.cursor()
            
            # Vérifier les tables existantes
            cursor.execute("SHOW TABLES;")
            tables = cursor.fetchall()
            print("Tables disponibles:", [table[0] for table in tables])
            
            # Vérifier la structure de la table administration si elle existe
            if ('administration',) in tables:
                cursor.execute("DESCRIBE administration;")
                print("\nStructure de la table 'administration':")
                for column in cursor:
                    print(column)
            else:
                print("\nLa table 'administration' n'existe pas dans la base de données.")
            
            # Vérifier les colonnes de la table administration
            cursor.execute("""
                SELECT COLUMN_NAME 
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_SCHEMA = 'donnee_app' 
                AND TABLE_NAME = 'administration';
            """)
            columns = cursor.fetchall()
            print("\nColonnes de la table 'administration':", [col[0] for col in columns])
            
    except Error as e:
        print(f"Erreur lors de la connexion à MySQL: {e}")
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()
            print("\nConnexion MySQL fermée")

if __name__ == "__main__":
    check_table_structure()

import flet as ft
import mysql.connector
from mysql.connector import Error

# Définition des couleurs
BG = "#041955"   # Bleu foncé
FWG = "#FFFFFF"  # Blanc
FG = "#3450a1"   # Bleu clair
PINK = "#eb06ff" # Rose

# Fonction pour récupérer les données de la base de données
def fetch_statistics():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='donnee_app',
            user='root',
            password='labo'
        )

        if connection.is_connected():
            cursor = connection.cursor()
            cursor.execute("""
                SELECT 
                    e.Nom, e.Prenoms, 
                    COUNT(pe.Id_pres) AS nb_presences, 
                    SUM(TIMESTAMPDIFF(MINUTE, pe.Heure_debut, pe.Heure_fin)) AS total_minutes
                FROM 
                    Enseignant e
                LEFT JOIN 
                    Presence_ens pe ON e.Id_ens = pe.Id_ens
                GROUP BY 
                    e.Id_ens 
            """)
            stats = cursor.fetchall()
            return stats

    except Error as e:
        print(f"Erreur lors de la connexion à MySQL: {e}")
        return None

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("Connexion MySQL fermée")

# statistique en courbe
class State:
    toggle = True

s = State()

def page_stat1(page: ft.Page):
    title = ft.Text(" STATISTIQUES ", size=30, color="WHITE", weight=ft.FontWeight.BOLD)
    stats = fetch_statistics()
    if stats:
        data_points = [ft.LineChartDataPoint(idx, stat[2]) for idx, stat in enumerate(stats)]
        # 1. Statistiques en courbe
        data_1 = [
            ft.LineChartData(
                data_points=data_points,
                stroke_width=8,
                color=ft.Colors.LIGHT_GREEN,
                curved=True,
                stroke_cap_round=True,
            )
        ]
    else:
        data_1 = []

    chart_1 = ft.LineChart(
        data_series=data_1,
        border=ft.Border(
            bottom=ft.BorderSide(4, ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE))
        ),
        left_axis=ft.ChartAxis(
            labels=[
                ft.ChartAxisLabel(
                    value=1,
                    label=ft.Text("1H", size=14, weight=ft.FontWeight.BOLD),
                ),
                ft.ChartAxisLabel(
                    value=2,
                    label=ft.Text("2H", size=14, weight=ft.FontWeight.BOLD),
                ),
                ft.ChartAxisLabel(
                    value=3,
                    label=ft.Text("3H", size=14, weight=ft.FontWeight.BOLD),
                ),
            ],
            labels_size=40,
        ),
        bottom_axis=ft.ChartAxis(
            labels=[
                ft.ChartAxisLabel(
                    value=2,
                    label=ft.Container(
                        ft.Text(
                            "SEP",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            color=ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE),
                        ),
                        margin=ft.margin.only(top=10),
                    ),
                ),
                ft.ChartAxisLabel(
                    value=7,
                    label=ft.Container(
                        ft.Text(
                            "OCT",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            color=ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE),
                        ),
                        margin=ft.margin.only(top=10),
                    ),
                ),
            ],
            labels_size=32,
        ),
        tooltip_bgcolor=ft.Colors.with_opacity(0.8, ft.Colors.BLUE_GREY),
        min_y=0,
        max_y=4,
        min_x=0,
        max_x=14,
        expand=True,
    )

    def toggle_data(e):
        if s.toggle:
            chart_1.data_series = data_1[:2]
            chart_1.data_series[2].point = True
            chart_1.max_y = 6
            chart_1.interactive = False
        else:
            chart_1.data_series = data_1
            chart_1.max_y = 4
            chart_1.interactive = True
        s.toggle = not s.toggle
        chart_1.update()

    # Retourner une liste contenant les contrôles de la page des statistiques
    return [
        ft.IconButton(icon=ft.icons.ARROW_BACK, icon_color="WHITE", on_click=lambda _: page.go('/page_statistiques')),
        title,ft.IconButton(ft.Icons.REFRESH, on_click=toggle_data),
        chart_1,
    ]
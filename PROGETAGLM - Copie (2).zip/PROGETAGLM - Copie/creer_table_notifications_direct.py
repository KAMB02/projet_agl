import mysql.connector
from mysql.connector import Error

def create_notifications_table():
    try:
        print("Tentative de connexion à la base de données...")
        
        # Paramètres de connexion pour XAMPP (paramètres par défaut)
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",  # Mot de passe vide par défaut dans XAMPP
            database="donnee_app"
        )
        
        if connection.is_connected():
            db_info = connection.get_server_info()
            print(f"Connecté au serveur MySQL version {db_info}")
            
            cursor = connection.cursor()
            
            # Création de la table Notifications
            create_table_query = """
            CREATE TABLE IF NOT EXISTS Notifications (
                Id_notification INT PRIMARY KEY AUTO_INCREMENT,
                Id_utilisateur VARCHAR(20) NOT NULL,
                Type_utilisateur ENUM('etudiant', 'enseignant', 'administration') NOT NULL,
                Titre VARCHAR(100) NOT NULL,
                Message TEXT NOT NULL,
                Type_notification ENUM('info', 'avertissement', 'urgence', 'confirmation') DEFAULT 'info',
                Date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                Date_lecture TIMESTAMP NULL,
                Lu TINYINT(1) DEFAULT 0,
                Lien VARCHAR(255) NULL,
                Priorite ENUM('basse', 'moyenne', 'haute') DEFAULT 'moyenne',
                INDEX idx_utilisateur (Id_utilisateur, Type_utilisateur)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
            
            cursor.execute(create_table_query)
            print("Table 'Notifications' créée avec succès.")
            
            # Ajout de données de test
            insert_query = """
            INSERT INTO Notifications 
            (Id_utilisateur, Type_utilisateur, Titre, Message, Type_notification, Priorite)
            VALUES 
            ('0141973436', 'etudiant', 'Bienvenue', 'Votre compte a été créé avec succès !', 'info', 'basse'),
            ('0141973436', 'etudiant', 'Présence', 'Votre présence a été enregistrée.', 'confirmation', 'moyenne');
            """
            
            cursor.execute(insert_query)
            connection.commit()
            print("Données de test insérées avec succès.")
            
            # Vérification que la table a été créée
            cursor.execute("SHOW TABLES LIKE 'Notifications'")
            result = cursor.fetchone()
            if result:
                print("✅ Vérification réussie: La table 'Notifications' existe bien.")
            else:
                print("❌ La table 'Notifications' n'a pas pu être créée.")
    
    except Error as e:
        print(f"Erreur lors de la connexion à MySQL: {e}")
    
    finally:
        if 'connection' in locals() and connection.is_connected():
            cursor.close()
            connection.close()
            print("Connexion MySQL fermée.")

if __name__ == "__main__":
    print("=== Création de la table Notifications ===")
    create_notifications_table()
    print("=== Opération terminée ===")

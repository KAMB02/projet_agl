import mysql.connector
from mysql.connector import Error

def execute_query(cursor, query, params=None, fetch_one=False):
    """Exécute une requête et retourne les résultats"""
    cursor.execute(query, params or ())
    if fetch_one:
        return cursor.fetchone()
    return cursor.fetchall()

def verifier_donnees():
    connection = None
    cursor = None
    try:
        # Connexion à la base de données
        print("Connexion à la base de données...")
        connection = mysql.connector.connect(
            host='localhost',
            database='donnee_app',
            user='root',
            password='Kamssone25',
            port='3308',
            charset='utf8'
        )

        if connection.is_connected():
            cursor = connection.cursor(dictionary=True)
            
            # Vérifier si la table Presence_ens existe
            print("\nVérification de l'existence de la table Presence_ens...")
            tables = execute_query(cursor, "SHOW TABLES LIKE 'Presence_ens'")
            if not tables:
                print("❌ La table Presence_ens n'existe pas dans la base de données.")
                return
            
            # Afficher la structure de la table
            print("\n🔍 Structure de la table Presence_ens:")
            columns = execute_query(cursor, "DESCRIBE Presence_ens")
            print("\n{:<15} {:<15} {:<10} {:<10} {:<15} {:<10}".format(
                "Champ", "Type", "Null", "Clé", "Default", "Extra"
            ))
            print("-" * 80)
            for column in columns:
                print("{:<15} {:<15} {:<10} {:<10} {:<15} {:<10}".format(
                    column['Field'], 
                    column['Type'], 
                    column['Null'], 
                    column['Key'] or "-", 
                    str(column['Default']) if column['Default'] is not None else "NULL", 
                    column['Extra'] or "-"
                ))
            
            # Compter le nombre d'entrées dans Presence_ens
            count_result = execute_query(cursor, "SELECT COUNT(*) as count FROM Presence_ens", fetch_one=True)
            count = count_result['count'] if count_result else 0
            print(f"\n📊 Nombre d'entrées dans Presence_ens: {count}")
            
            if count > 0:
                # Afficher les premières entrées
                print("\n📋 Premières entrées dans Presence_ens:")
                entries = execute_query(cursor, "SELECT * FROM Presence_ens LIMIT 3")
                
                if entries:
                    # Afficher les noms des colonnes
                    columns = list(entries[0].keys())
                    print("\nColonnes disponibles:", ", ".join(columns))
                    
                    # Afficher les en-têtes
                    header = " | ".join(f"{col:<15}" for col in columns)
                    print("\n" + header)
                    print("-" * len(header))
                    
                    # Afficher les données
                    for row in entries:
                        values = [str(row.get(col, 'N/A'))[:15] for col in columns]
                        print(" | ".join(f"{val:<15}" for val in values))
            
            # Vérifier les enseignants référencés
            print("\n🔍 Vérification des enseignants référencés dans Presence_ens...")
            enseignants = execute_query(cursor, """
                SELECT e.Id_ens, e.Nom, e.Prenoms, COUNT(p.Id_pres) as nb_presences
                FROM Enseignant e
                LEFT JOIN Presence_ens p ON e.Id_ens = p.Id_ens
                GROUP BY e.Id_ens, e.Nom, e.Prenoms
                ORDER BY nb_presences DESC
            """)
            
            if enseignants:
                print("\n{:<10} {:<20} {:<20} {:<10}".format(
                    "ID", "Nom", "Prénom", "Présences"
                ))
                print("-" * 70)
                for ens in enseignants:
                    print("{:<10} {:<20} {:<20} {:<10}".format(
                        ens['Id_ens'],
                        ens['Nom'],
                        ens['Prenoms'],
                        ens['nb_presences']
                    ))
            else:
                print("\nAucun enseignant trouvé dans la base de données.")
            
    except Error as e:
        print(f"\n❌ Erreur lors de la connexion à MySQL : {e}")
        import traceback
        traceback.print_exc()
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()
            print("\n✅ Connexion MySQL fermée")

if __name__ == "__main__":
    print("=== VÉRIFICATION DE LA TABLE PRESENCE_ENS ===")
    verifier_donnees()

import mysql.connector
from mysql.connector import Error

def test_connection(host, user, password, database=None):
    try:
        print(f"\nTentative de connexion à la base de données...")
        print(f"Hôte: {host}")
        print(f"Utilisateur: {user}")
        print(f"Base de données: {database if database else 'Aucune'}")
        
        connection_params = {
            'host': host,
            'user': user,
            'password': password
        }
        
        if database:
            connection_params['database'] = database
        
        conn = mysql.connector.connect(**connection_params)
        
        if conn.is_connected():
            db_info = conn.get_server_info()
            print(f"\n✅ Connecté au serveur MySQL version {db_info}")
            
            cursor = conn.cursor()
            
            # Afficher les bases de données disponibles
            cursor.execute("SHOW DATABASES")
            print("\nBases de données disponibles:")
            for (db,) in cursor:
                print(f"- {db}")
            
            # Si une base de données est spécifiée, afficher ses tables
            if database:
                cursor.execute(f"USE {database}")
                cursor.execute("SHOW TABLES")
                tables = cursor.fetchall()
                
                if tables:
                    print(f"\nTables dans la base de données '{database}':")
                    for i, (table,) in enumerate(tables, 1):
                        print(f"{i}. {table}")
                else:
                    print(f"\nAucune table trouvée dans la base de données '{database}'.")
            
            return True
    
    except Error as e:
        print(f"\n❌ Erreur de connexion: {e}")
        return False
    
    finally:
        if 'conn' in locals() and conn.is_connected():
            cursor.close()
            conn.close()
            print("\nConnexion fermée.")

# Tester avec différentes configurations
print("=== Test de connexion à MySQL ===")

# Essai 1: Connexion sans spécifier de base de données
print("\n--- Essai 1: Connexion au serveur MySQL ---")
test_connection(host="localhost", user="root", password="")

# Essai 2: Connexion avec la base de données donnee_app
print("\n--- Essai 2: Connexion à la base 'donnee_app' ---")
test_connection(host="localhost", user="root", password="", database="donnee_app")

# Essai 3: Essayer avec un autre utilisateur si nécessaire
# test_connection(host="localhost", user="votre_utilisateur", password="votre_mot_de_passe", database="donnee_app")

print("\n=== Fin des tests de connexion ===")

import socket
import sys

def test_mysql_port(host="localhost", port=3306, timeout=3):
    """Teste si le port MySQL est ouvert sur l'hôte spécifié"""
    try:
        print(f"Test de connexion à {host}:{port}...")
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        
        if result == 0:
            print(f"✅ Le port {port} est ouvert sur {host}")
            return True
        else:
            print(f"❌ Le port {port} est fermé sur {host} ou le service ne répond pas")
            return False
    except Exception as e:
        print(f"❌ Erreur lors de la connexion à {host}:{port} : {e}")
        return False

def main():
    print("=== Test de connexion au port MySQL (3306) ===")
    
    # Tester localhost
    test_mysql_port("localhost")
    
    # Tester l'adresse IP locale
    test_mysql_port("127.0.0.1")
    
    # Tester d'autres ports MySQL courants (au cas où le port serait différent)
    for port in [3307, 3308, 3309, 3310, 1433]:
        test_mysql_port("localhost", port)
    
    print("\nRésumé :")
    print("- Si aucun port n'est ouvert, vérifiez que le service MySQL est bien démarré")
    print("- Si le port est différent de 3306, vous devrez spécifier ce port dans vos connexions")
    print("- Vérifiez également les paramètres de pare-feu qui pourraient bloquer la connexion")

if __name__ == "__main__":
    main()

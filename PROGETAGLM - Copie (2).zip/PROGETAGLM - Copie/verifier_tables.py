import mysql.connector

print("Début du script de vérification des tables...")

try:
    print("Tentative de connexion à la base de données...")
    conn = mysql.connector.connect(
        host="localhost",
        user="root",  # Utilisateur par défaut de XAMPP
        password="",  # Mot de passe par défaut de XAMPP (vide)
        database="donnee_app"
    )
    print("Connexion à la base de données réussie !")
    
    cursor = conn.cursor()
    
    # Vérifier d'abord si la base de données existe
    cursor.execute("SHOW DATABASES LIKE 'donnee_app'")
    if not cursor.fetchone():
        print("ERREUR: La base de données 'donnee_app' n'existe pas.")
        exit(1)
    
    print("\nRécupération de la liste des tables...")
    cursor.execute("SHOW TABLES")
    tables = cursor.fetchall()
    
    if not tables:
        print("Aucune table trouvée dans la base de données.")
    else:
        print("\nTables dans la base de données 'donnee_app':")
        for i, table in enumerate(tables, 1):
            print(f"{i}. {table[0]}")
    
    # Vérifier si la table Notifications existe
    print("\nVérification de l'existence de la table 'Notifications'...")
    cursor.execute("""
        SELECT COUNT(*)
        FROM information_schema.tables 
        WHERE table_schema = 'donnee_app' 
        AND table_name = 'Notifications'
    """)
    
    if cursor.fetchone()[0] == 1:
        print("✅ La table 'Notifications' existe bien.")
    else:
        print("❌ La table 'Notifications' n'existe pas encore.")
        
        # Essayer de créer la table directement
        print("\nTentative de création de la table 'Notifications'...")
        try:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Notifications (
                    Id_notification INT PRIMARY KEY AUTO_INCREMENT,
                    Id_utilisateur VARCHAR(20) NOT NULL,
                    Type_utilisateur ENUM('etudiant', 'enseignant', 'administration') NOT NULL,
                    Titre VARCHAR(100) NOT NULL,
                    Message TEXT NOT NULL,
                    Type_notification ENUM('info', 'avertissement', 'urgence', 'confirmation') DEFAULT 'info',
                    Date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    Date_lecture TIMESTAMP NULL,
                    Lu TINYINT(1) DEFAULT 0,
                    Lien VARCHAR(255) NULL,
                    Priorite ENUM('basse', 'moyenne', 'haute') DEFAULT 'moyenne',
                    INDEX idx_utilisateur (Id_utilisateur, Type_utilisateur)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """)
            conn.commit()
            print("✅ Table 'Notifications' créée avec succès !")
            
            # Ajouter des données de test
            cursor.execute("""
                INSERT INTO Notifications 
                (Id_utilisateur, Type_utilisateur, Titre, Message, Type_notification, Priorite)
                VALUES 
                ('0141973436', 'etudiant', 'Bienvenue', 'Votre compte a été créé avec succès !', 'info', 'basse'),
                ('0141973436', 'etudiant', 'Présence', 'Votre présence a été enregistrée.', 'confirmation', 'moyenne')
            """)
            conn.commit()
            print("✅ Données de test ajoutées avec succès !")
            
        except mysql.connector.Error as create_err:
            print(f"❌ Erreur lors de la création de la table: {create_err}")
    
except mysql.connector.Error as err:
    print(f"❌ Erreur MySQL: {err}")
    
finally:
    if 'conn' in locals() and conn.is_connected():
        cursor.close()
        conn.close()
        print("\nConnexion MySQL fermée.")

print("\nFin du script.")

import mysql.connector
from mysql.connector import Error

def check_enseignant_data():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='donnee_app',
            user='root',
            password='Kamssone25',
            port='3308'
        )
        
        if connection.is_connected():
            cursor = connection.cursor()
            
            # Vérifier les données de l'enseignant
            cursor.execute("SELECT * FROM Enseignant WHERE Id_ens = '0701010101'")
            result = cursor.fetchone()
            
            if result:
                print("\nDonnées de l'enseignant trouvées:")
                print(f"ID: {result[0]}")
                print(f"Nom: {result[2]}")
                print(f"Prenoms: {result[3]}")
                print(f"Email: {result[4]}")
                print(f"Numero: {result[5]}")
                print(f"Adresse: {result[6]}")
                print(f"Mot_de_passe: {result[7]}")
            else:
                print("\nAucun enseignant trouvé avec l'ID 0701010101")
            
            # Vérifier combien d'enseignants existent
            cursor.execute("SELECT COUNT(*) FROM Enseignant")
            count = cursor.fetchone()[0]
            print(f"\nNombre total d'enseignants dans la base: {count}")
            
            # Vérifier les données de tous les enseignants
            cursor.execute("SELECT Id_ens, Nom, Prenoms, Adresse FROM Enseignant")
            enseignants = cursor.fetchall()
            print("\nListe de tous les enseignants:")
            for enseignant in enseignants:
                print(f"ID: {enseignant[0]}, Nom: {enseignant[1]}, Prenoms: {enseignant[2]}, Adresse: {enseignant[3]}")
            
    except Error as e:
        print(f"Erreur lors de la connexion à la base de données: {e}")
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

if __name__ == "__main__":
    check_enseignant_data()
